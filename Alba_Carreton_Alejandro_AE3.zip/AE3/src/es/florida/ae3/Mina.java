package es.florida.ae3;

public class Mina {
	int stock;
	public Mina(int stock) {
		this.stock=stock;
	}
}
