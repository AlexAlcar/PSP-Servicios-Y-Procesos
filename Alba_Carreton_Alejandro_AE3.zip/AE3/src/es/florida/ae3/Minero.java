package es.florida.ae3;

public class Minero {
	int bolsa;
	int tiempoExtraccion=2;
	public Minero() {
		this.bolsa=0;
	}
	
	public void extraerRecurso(Mina mina) {
		synchronized (mina) {
			if(mina.stock>0) {
				try {
					Thread.sleep(tiempoExtraccion);
					mina.stock--;
					bolsa++;
					System.out.println("Stock: "+mina.stock+" Bolsa: "+bolsa);
				} catch (InterruptedException e) {e.printStackTrace();}
			}
		}
	}
}